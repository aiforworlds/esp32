/**
 ****************************************************************************************************
 * @file        main.c
 * @author      正点原子团队(ALIENTEK)
 * @version     V1.0
 * @date        2024-06-25
 * @brief       QMI8658A六轴传感器实验
 * @license     Copyright (c) 2020-2032, 广州市星翼电子科技有限公司
 ****************************************************************************************************
 * @attention
 *
 * 实验平台:正点原子 ESP32S3 BOX 开发板
 * 在线视频:www.yuanzige.com
 * 技术论坛:www.openedv.com
 * 公司网址:www.alientek.com
 * 购买地址:openedv.taobao.com
 *
 ****************************************************************************************************
 */

#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "nvs_flash.h"
#include "led.h"
#include "key.h"
#include "iic.h"
#include "usart.h"
#include "xl9555.h"
#include "lcd.h"
#include "imu.h"
#include "qmi8658a.h"


i2c_obj_t i2c0_master;
i2c_obj_t i2c1_master;

/**
 * @brief   显示数据
 * @param   x: 标题起始X坐标
 * @param   y: 标题起始Y坐标
 * @param   data: 温度或俯仰角或横滚角或航向角数据
 * @retval  无
 */
static void show_data(uint16_t x, uint16_t y, float data)
{
    int16_t temp;

    temp = data *10;

    if (temp < 0)
    {
        lcd_show_char(x + 6 * 8, y, '-', 16, 0, BLUE);
        temp = -temp;
    }
    else
    {
        lcd_show_char(x + 6 * 8, y, ' ', 16, 0, BLUE);
    }

    lcd_show_num(x + 7 * 8, y, temp / 10, 3, 16, BLUE);
    lcd_show_num(x + 11 * 8, y, temp % 10, 1, 16, BLUE);
}

/**
 * @brief       传送数据给 ANO_TC匿名科创地面站v4.exe
 * @param       fun  : 功能字. 0XA0~0XAF
 * @param       data : 数据缓存区,最多28字节!!
 * @param       len  : data区有效数据个数
 * @retval      无 
 */
void usart1_niming_report(uint8_t fun, uint8_t *data, uint8_t len)
{
    unsigned char send_buf[32] = {0};
    uint8_t i;

    if (len > 28)
    {
        return;    /* 最多28字节数据 */
    }

    send_buf[len + 4] = 0;  /* 校验数置零 */
    send_buf[0] = 0XAA;     /* 帧头 */
    send_buf[1] = 0XAA;     /* 帧头 */
    send_buf[2] = fun;      /* 功能字 */
    send_buf[3] = len;      /* 数据长度 */

    for (i = 0; i < len; i++)
    {
        send_buf[4 + i] = data[i];             /* 复制数据 */
    }
    
    for (i = 0; i < len + 4; i++)
    {
        send_buf[len + 4] += send_buf[i];      /* 计算校验和 */
    }
    
    uart_write_bytes(USART_UX, (const char*)send_buf, len + 5);
}

/**
 * @brief       发送加速度传感器数据和陀螺仪数据
 * @param       aacx,aacy,aacz    : x,y,z三个方向上面的加速度值
 * @param       gyrox,gyroy,gyroz : x,y,z三个方向上面的陀螺仪值
 * @retval      无 
 */
void qmi8658a_send_data(short aacx, short aacy, short aacz, short gyrox, short gyroy, short gyroz)
{
    uint8_t tbuf[18];
    tbuf[0] = (aacx >> 8) & 0XFF;
    tbuf[1] = aacx & 0XFF;
    tbuf[2] = (aacy >> 8) & 0XFF;
    tbuf[3] = aacy & 0XFF;
    tbuf[4] = (aacz >> 8) & 0XFF;
    tbuf[5] = aacz & 0XFF;
    tbuf[6] = (gyrox >> 8) & 0XFF;
    tbuf[7] = gyrox & 0XFF;
    tbuf[8] = (gyroy >> 8) & 0XFF;
    tbuf[9] = gyroy & 0XFF;
    tbuf[10] = (gyroz >> 8) & 0XFF;
    tbuf[11] = gyroz & 0XFF;
    /* 无磁力计数据,所以这里直接屏蔽掉.用0替代. */
    tbuf[12]=0;             
    tbuf[13]=0;
    tbuf[14]=0;
    tbuf[15]=0;
    tbuf[16]=0;
    tbuf[17]=0;
    usart1_niming_report(0X02, tbuf, 18);       /* 自定义帧,0X02 */
}

/**
 * @brief       通过串口1上报结算后的姿态数据给电脑
 * @param       roll     : 横滚角.单位0.1度。 -9000 -> 9000 对应 -90.00  ->  90.00度
 * @param       pitch    : 俯仰角.单位 0.1度。-18000 -> 18000 对应 -180.00 -> 180.00 度
 * @param       yaw      : 航向角.单位为0.1度 -18000 -> 18000  对应 -180.00 -> 180.00 度
 * @param       prs      : 气压计高度,单位:cm
 * @param       fly_mode : 飞行模式
 * @param       armed    : 锁定状态
 * @retval      无 
 */
void usart1_report_imu(short roll, short pitch, short yaw, int prs, uint8_t fly_mode, uint8_t armed)
{
    uint8_t tbuf[12];
  
    tbuf[0] = (roll >> 8) & 0XFF;
    tbuf[1] = roll & 0XFF;
    tbuf[2] = (pitch >> 8) & 0XFF;
    tbuf[3] = pitch & 0XFF;
    tbuf[4] = (yaw >> 8) & 0XFF;
    tbuf[5] = yaw & 0XFF;
    tbuf[6] = (prs >> 24) & 0XFF;
    tbuf[7] = (prs >> 16) & 0XFF;
    tbuf[8] = (prs >> 8) & 0XFF;
    tbuf[9] = prs & 0XFF;
    tbuf[10] = fly_mode;
    tbuf[11] = armed;
    usart1_niming_report(0X01, tbuf, 12);   /* 状态帧,0X01 */
}

/**
 * @brief       程序入口
 * @param       无
 * @retval      无
 */
void app_main(void)
{
    uint8_t t = 0;
    uint8_t key;
    uint8_t report = 0;
    float temperature;
    float gyro[3];
    float accel[3];
    float euler_angle[3] = {0, 0, 0};
    esp_err_t ret;
    
    ret = nvs_flash_init();             /* 初始化NVS */
    lcd_cfg_t lcd_config_info = {0};
    lcd_config_info.notify_flush_ready = NULL;

    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND)
    {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ret = nvs_flash_init();
    }

    led_init();                         /* 初始化LED */
    key_init();                         /* 初始化KEY */
    i2c0_master = iic_init(I2C_NUM_0);  /* 初始化IIC0 */
    xl9555_init(i2c0_master);           /* 初始化XL9555 */
    lcd_init(lcd_config_info);          /* 初始化LCD */
    qmi8658_init(i2c0_master);          /* 初始化QMI8658A */
    usart_init(115200);                 /* 初始化串口 */

    lcd_show_string(30, 50, 200, 16, 16, "ESP32", RED);
    lcd_show_string(30, 70, 200, 16, 16, "QMI8658A TEST", RED);
    lcd_show_string(30, 90, 200, 16, 16, "ATOM@ALIENTEK", RED);
    lcd_show_string(30, 110, 200, 16, 16, "BOOT:UPLOAD ON/OFF", RED);

    lcd_show_string(30, 130, 200, 16, 16, "UPLOAD OFF", BLUE);
    lcd_show_string(30, 150, 200, 16, 16, "Temp :    . C", BLUE);
    lcd_show_string(30, 170, 200, 16, 16, "Pitch:    . C", BLUE);
    lcd_show_string(30, 190, 200, 16, 16, "Roll :    . C", BLUE);
    lcd_show_string(30, 210, 200, 16, 16, "Yaw  :    . C", BLUE);

    while (1)
    {
        qmi8658_read_xyz(accel, gyro);
        key = key_scan(0);

        if (key == BOOT_PRES)                    /* 0.2秒左右更新一次三轴原始值 */
        {
            /* 切换匿名数据上报开关 */
            report = !report;

            if (report == 0)
            {
                lcd_show_string(30, 130, 200, 16, 16, "UPLOAD OFF", BLUE);
            }
            else
            {
                lcd_show_string(30, 130, 200, 16, 16, "UPLOAD ON ", BLUE);
            }
        }

        /* 获取并显示温度 */
        show_data(30, 150, qmi8658_get_temperature());

        /* 获取并显示欧拉角 */
        if (g_imu_init)
        {
            imu_get_eulerian_angles(accel, gyro, euler_angle, IMU_DELTA_T);
            show_data(30, 170, euler_angle[0]);
            show_data(30, 190, euler_angle[1]);
            show_data(30, 210, euler_angle[2]);
            
            if (report != 0)
            {
                /* 上报匿名状态帧 */
                qmi8658a_send_data(accel[0], accel[1], accel[2], gyro[0], gyro[1], gyro[2]);  /* 发送加速度+陀螺仪原始数据 */
                usart1_report_imu((int)(euler_angle[1] * 100), (int)(euler_angle[0] * 100), (int)(euler_angle[2] * 100), 0, 0, 0); /* Pitch和Roll角位置调换 */
            }
        }
        if (++t == 10)
        {
            t = 0;
            LEDR_TOGGLE();
        }
        
        vTaskDelay(10);
    }
}
